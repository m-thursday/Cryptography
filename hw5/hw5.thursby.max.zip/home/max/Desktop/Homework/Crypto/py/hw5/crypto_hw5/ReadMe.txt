Instructions For How To Run The Code:
No setup required
- for both HMAC and RSA alice and bob need to be ran in seperate terminals
- Alice will take an 18 byte message string for both files
- Bob takes no user input
- Analysis and Collision should be ran on their own
- Analysis takes a 7 byte input
- Collision takes no input
